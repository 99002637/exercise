﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using Exercisee1.Commands;

namespace Exercisee1.ViewModel
{
     public class GridViewModel: INotifyPropertyChanged
	{
		
		public class Student
		{
            private int id;
            public int Id
            {
                get { return id; }
                set { id = value; }
            }

			private string name;

			public string Name
			{
				get { return name; }
				set { name = value; }
			}

            private int birthday;

            public int Birthday
            {
                get { return birthday; }
                set { birthday = value; }
            }

            private string gender;

            public string Gender
            {
                get { return gender; }
                set { gender = value; }
            }

        }
		
		public class DataGridContent
		{

            private string name;

            public string Name
            {
                get { return name; }
                set { name = value; }
            }



            private int birthday;

            public int Birthday
            {
                get { return birthday; }
                set { birthday = value; }
            }
            private string gender;

            public string Gender
            {
                get { return gender; }
                set { gender = value; }
            }
            private bool isselected;

            public bool IsSelected
            {
                get { return isselected; }
                set { isselected = value; }
            }

        }
        private GridCommand viewdata;

        public GridCommand ViewData
        {
            get { return viewdata; }
             
        }
        private GridCommand viewalldata;

        public GridCommand ViewAllData
        {
            get { return viewalldata; }
            
        }
        private GridCommand search;

        public GridCommand Search
        {
            get { return search; }
            
        }

        public class ListOfStudents
		{
            private List<DataGridContent> pupils;
            public List<DataGridContent> Pupils { get; set; }
		}
		GridViewModel Model = new GridViewModel();

        public GridViewModel()
        {

        }

        public event PropertyChangedEventHandler PropertyChanged;

		private void OnPropertyChanged(string propertyName)
		{
			if (PropertyChanged != null)
				PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
		}
        public void SimpleViewData()
        {
            
        }
	}
}
