﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace DataGridConfiguration
{
    class MainWindowViewModel : INotifyPropertyChanged
    {
        ListOfStudents Data;
        private List<DataGridContent> student;

        public List<DataGridContent> Student
        {
            get { return student; }
            set
            {
                student = value;
                OnPropertyChanged("Student");
            }
        }


        public MainWindowViewModel()
        {
            Data = Deserialzation();
            this.Student = Data.Pupils;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        public static ListOfStudents Deserialzation()
        {
            ListOfStudents s;
            try
            {
                XmlSerializer sl = new XmlSerializer(typeof(ListOfStudents));
                FileStream fs = new FileStream("StudentData.xml", FileMode.Open, FileAccess.Read);
                s = (ListOfStudents)sl.Deserialize(fs);
                //Student.ItemsSource = s;
                fs.Flush();
                fs.Close();
                return s;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return null;
        }
    }
	public class DataGridContent
	{
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private string birthday;

        public string Birthday
        {
            get { return birthday; }
            set { birthday = value; }
        }

        private string gender;

        public string Gender
        {
            get { return gender; }
            set { gender = value; }
        }

        private bool isSelected;

        public bool IsSelected
        {
            get { return isSelected; }
            set { isSelected = value; }
        }

    }
	public class ListOfStudents
	{
        private List<DataGridContent> pupils;

        public List<DataGridContent> Pupils
        {
            get { return pupils; }
            set { pupils = value; }
        }
    }
}
